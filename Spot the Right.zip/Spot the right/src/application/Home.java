package application;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.StackPane;
//import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;      // vertical button
import javafx.scene.layout.HBox;      //horizontal button
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
//import javafx.scene.Shape;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;

public class Home extends Application{

    private Stage window;
    private Scene scene1, scene2, scene3,scene4;
    private int word_mode;
    //public String[]a = {"one","two","three","four","five","six"};
    
    
    public String[] a = {"one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve",
    		"one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve"};
  
    public static Action act = new Action();
    ListView<String> viewlist;
   
    //private ArrayList<String> word = new ArrayList<String>();


    public static void main(String[] args) throws Exception{ 
    	Scanner sc1 = new Scanner(System.in);
    	
    	act.ReadFile();
    	///////////////////////////////////////////////////////////////// read meaning.txt into hash map
   /* 	Map<String,String> map  = new HashMap<String,String>();
		FileReader f = new FileReader ("C:\\Users\\User\\eclipse-workspace\\Spot the right\\src\\application\\meaning.txt"); 
		BufferedReader in = new BufferedReader(f);
        String line = "";
        while ((line = in.readLine()) != null) {
            String parts[] = line.split("\t");
            map.put(parts[0], parts[1]);
        }
        in.close();
        System.out.println(map.toString());
    	//////////////////////////////////////////////////////////////////
    	System.out.println("Word chosen:");
    	String a = sc1.next();
    	act.returnMeaning(a,map);          */
    	/*System.out.println("Enter word");
    	String str = sc1.next();
    	act.validation(str);
    	act.generate(str);
    	sc1.close();*/
		// a method inside class Application, used to set up program as the JavaFX application.
    	launch(args); 
    	}
    
 

    @Override                       //main JavaFX code *************
    public void start(Stage primaryStage) throws Exception{
        window = primaryStage;
        window.setTitle("Anagram"); //title of window
        //Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));

        ImageView imageview = new ImageView("/application/3.jpg");
        imageview.setFitHeight(220);
        Label label1 = new Label ("\n\n\n\n  Welcome to\n'Spot the right'!");
        label1.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR,35));
        label1.setAlignment(Pos.CENTER);

        RadioButton player[] = new RadioButton[3]; // create radio button to get num of player
        player[0] = new RadioButton("3-words mode");
        player[1] = new RadioButton("4-words mode");

       ToggleGroup mode = new ToggleGroup(); // make user select one option only
        player[0].setToggleGroup(mode); player[1].setToggleGroup(mode);

        //------------------------------------------------------------------------Scene 1
        Button button1 = new Button("Next");
        Button button2 = new Button("Back");
        Button button3 = new Button("Start");
        
        //layout 1
        HBox hb1 = new HBox(10);
        hb1.getChildren().addAll(player[0], player[1]); // horizontal choice for player
        hb1.setAlignment(Pos.CENTER);
        VBox layout1 = new VBox(80);
        layout1.setAlignment(Pos.CENTER); // SET the alignment, must sync with the others
        layout1.getChildren().addAll(label1, hb1, button1);
        StackPane sPane1 = new StackPane();
        sPane1.getChildren().add(imageview); // add image
        sPane1.setAlignment(Pos.TOP_CENTER);
        sPane1.getChildren().add(layout1);
        scene1 = new Scene (sPane1,500,600);

        button1.setOnAction( e->

        // get word mode from radio button
                {
                    if (player[0].isSelected())
                        this.word_mode = 3;
                    else if (player[1].isSelected())
                        this.word_mode = 4;
                    else
                        return;

                    //------------------redirect to scene 2----------------------------------------------
                    //label in scene 2
                    Label label2 = new Label("Mode chosen: " + word_mode + "-words");
                    Label label3 = new Label("\n\n\n\n\n\nEach game has one word to be guess."
                    		+ "\n You need to spot the right word set by system!");
                    label2.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.REGULAR, 15));
                    label2.setAlignment(Pos.CENTER);
                    label2.setFont(Font.font("Arial", FontPosture.REGULAR, 35));
                    label2.setAlignment(Pos.CENTER);
                    //option to choose button
                    HBox layout2 = new HBox(10);

                    layout2.getChildren().addAll(button2, button3);
                    layout2.setAlignment(Pos.CENTER);
                    // create stack pane
                    StackPane sPane2 = new StackPane();
                    sPane2.getChildren().addAll(label2, label3);
                    sPane2.setAlignment(Pos.TOP_CENTER);
                    sPane2.getChildren().add(layout2);
                    scene2 = new Scene(sPane2, 500, 600);
                    window.setScene(scene2);
                    window.show();
                });
        button2.setOnAction(e -> window.setScene(scene1)); // If user select 'Back', back to Scene1
        //If select 'Start', the game is started.
        button3.setOnAction(e-> {
			try {
				//GameStart(act.original);
				displayAnagram2(a);
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} );
       
        window.setScene(scene1);
        window.setResizable(true);
        window.show();
    }
       
    	/////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    	public void GameStart(ArrayList<String> any) throws Exception{
/*    		if (word_mode == 3) {
    			}		*/
    		VBox vvbb = new VBox(10); 
    		Label label4 =new Label("Dear player, Choose one word:");
    		label4.setFont(Font.font("Arial", FontPosture.REGULAR, 25));
    		label4.setAlignment(Pos.CENTER);
    		Button button4 = new Button("Done");
    		viewlist = new ListView<>();
    		
    		/////////////////////////////////////////////// print a list of words for player choose
    		for(int t=0;t<(any.size());t++) {
    			viewlist.getItems().add(any.get(t));
    		}
    		
    		viewlist.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    		
    		
    		vvbb.getChildren().addAll(label4,viewlist,button4);
    		//vvbb.getChildren().add(button4);
    		//vvbb.setAlignment(Pos.BOTTOM_CENTER);
    		scene4 = new Scene(vvbb,500,600);
    		window.setScene(scene4);
    		window.show();

    		///////////////////////////////////////////// generate the anagram
    		button4.setOnAction(e-> {
				try {			
					button4Clicked();
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
    			//System.out.println("Word is:"+ selected);
			});
    	}
    	
    	private void button4Clicked() throws Exception {
    		String message="";
    		ObservableList<String> selected;
    		selected = viewlist.getSelectionModel().getSelectedItems();
    		message = selected.get(0);
    		act.generate(message);
    		//System.out.println(message);
    		//System.out.println(message.length());
    	}
    	 /////////////////////////////////////////////////////////////////////////////////////
    	/*public void showtime(ArrayList<String> pattern) {
    		for(int q=0;q<pattern.size();q++) {
    			System.out.println("HAIYAAa: "+pattern.get(q));
    		}
    	}*/
    	//////////////////////////////////////////////////////////////////////////////////////
    	
    	/*public void displayAnagram(ArrayList<String> pattern) throws Exception{  
    		//StringBuffer sb = new StringBuffer();
    		GridPane grid = new GridPane();
    		//grid.setPadding(new Insets(BUTTON_PADDING));
    		grid.setHgap(5);
    		grid.setVgap(5);
    		
    		//System.out.println("Size is"+pattern.size());
    		//System.out.println("Value at first is: "+ pattern.get(0));
    		String [] arr = new String [pattern.size()];
    		for(int q=0;q<pattern.size();q++) {
    			arr[q]=pattern.get(q);
    		}
    		System.out.println("Array has size: "+ arr.length );
    		
 
    		ScrollPane scrollPane = new ScrollPane(grid);
    		scene3 = new Scene(scrollPane,500,600);
   		
    		for(int i=0;i<(arr.length/6);i++) {
    		
    			for(int j=0;j<6;j++) {
    				int number = (arr.length/6+2)*i+j;
    				Button btn = new Button();
    				btn.setText("asd");
    				btn.setText((arr[number]));
    				//btn.setText(String.valueOf(arr[number]));
    				//btn.setText(String.valueOf(number));
    				//btn.setText(pattern.get(number));
        			grid.add(btn, j, i);   // column row
    			}	
    		}
    		
    		scene3 = new Scene(grid,500,600);
    		window.setScene(scene3);
			window.show();
    	}*/
    	
    	public void displayAnagram2(String[] a) throws Exception{  // 
    		
    		GridPane grid = new GridPane();
    		grid.setHgap(5);
    		grid.setVgap(5);
    		
    		ScrollPane scrollPane = new ScrollPane(grid);
    		scene3 = new Scene(scrollPane,500,600);
   		
    		for(int i=0;i<(a.length/6);i++) {
    		
    			for(int j=0;j<6;j++) {
    				int number = (a.length/6+2)*i+j;
    				Button btn = new Button();
    				
    				btn.setText((a[number]));
    				//btn.setText(String.valueOf(arr[number]));
    				//btn.setText(String.valueOf(number));
    				//btn.setText(pattern.get(number));
        			grid.add(btn, j, i);   // column row
    			}	
    		}
    		
    		scene3 = new Scene(grid,500,600);
    		window.setScene(scene3);
			window.show();
    	}
    	
    	
    	
    	/*
        public ImageView cardImage(Card card) { // Set the cards into images
            ImageView[] iv = new ImageView[54];

            iv[0] = new ImageView("00.PNG"); // Red 0
            iv[1] = new ImageView("01.PNG"); // Red 1
           */
    	
    /*window.addEventHandler(KeyEvent.KEY_PRESSED, (key)->{
    	if(key.getCode()==KeyCode.A) {System.out.println("You pressed A");}
    });*/
}




