package application;

import java.io.*;
//import java.util.Arrays;
//import java.util.Collections;
import java.util.*;
import java.lang.Character;

public class Action {
	
	//int count=0;
//    String [] arrayA = new String [30]];
	ArrayList<String> original = new ArrayList<>();
    public static Home home = new Home();
    
//-------------------------------------------------------------------------------------------------------
	public void ReadFile () throws Exception{		// read file
		File file = new File ("C:\\Users\\User\\eclipse-workspace\\Spot the right\\src\\application\\list.txt");
		Scanner sc = new Scanner(file);
		while(sc.hasNextLine())
		{
			original.add(sc.nextLine());
			//System.out.println(sc.nextLine());
		}
		sc.close();
		for(int a=0;a<original.size();a++){ System.out.println( a + "-> " +original.get(a)); }
	}
	
//-----------------------------------------------------------------------------------------------------
	public void returnMeaning(String a, Map<String,String> map) {
		System.out.println(map.get(a));
	}
	
//-------------------------------------------------------------------------------------------------------
	
	@SuppressWarnings("unchecked")
	public void generate(String word) throws Exception{
		
		Queue<Character> qq = new LinkedList<>();	//qq and ss are used to generate anagram
		Stack<Character> ss = new Stack<>();	//temp store pattern of word and pass to 'finish'
		Stack<Character> temp = new Stack<>();
		Stack<Character> temp1 = new Stack<>();
		ArrayList<String> pattern = new ArrayList<String>();
		int factorial, loop;
		pattern.clear();
		pattern.add(word);	// the original word always a first pattern.
		System.out.println(word.length());
		for(int i=0;i<word.length();i++) {
			ss.push(word.charAt(i));
			
		}	
		factorial = calFac(word.length()); // calculate the factorial of word length

		loop=0; 
		for(int c=1; c<factorial;c++) {
			String buffer =""; // buffer
			if(c%2==0)
				loop=3;
			if(c%2!=0)
				loop=2;
			if(c%2==0 && c%6==0) //4 words
				loop=4;
			if(c%2==0 && c%6==0 && c%24==0) //5 words
				loop=5;
			if(c%2==0 && c%6==0 && c%24==0 && c%120==0) //6 words
				loop=6;
			if(c%2==0 && c%6==0 && c%24==0 && c%120==0 && c%720==0) //7 words
				loop=7;
		
		for(int x=0; x<loop; x++){				//peek() -> return head without removing it
			//System.out.println(ss.peek());		// poll( return head and removing it
			qq.add(ss.pop());
			//ss.pop();
		}
		//System.out.println("----");
		for(int y=0; y<loop; y++){
			ss.push(qq.poll()); // push queue's first element
			//qq.poll(); //remove queue's first element 
			//System.out.println(ss.peek());
		}
		//System.out.println("/////////////////////////////");
		
		temp = (Stack<Character>)ss.clone();
		while(!temp.isEmpty()) {
			temp1.push(temp.pop());
		}
		while(!temp1.isEmpty()) {
			buffer= buffer + temp1.pop();
		}
		System.out.println("Buffer is "+ buffer);
		pattern.add(buffer);
		}// end of loop factorial
		//System.out.println("-----------------------------------------");
		System.out.println(pattern); System.out.println();
		System.out.println("Total pattern: " + pattern.size());
		home.displayAnagram(pattern);
		//home.showtime(pattern);
		ss.clear();
		qq.clear();
	}
//------------------------------------------------------------------------------------------------------

	public int calFac(int n){
		int fac=1;
		for(int i=1;i<=n;i++)
			fac*=i; 			//eg:3, 3*2*1=6
		return fac;
		}
//------------------------------------------------------------------------------------------------------
	
	public void validation(String word) {
		char word1;
	
	if(word.length()<0 || word.length()>7)	//input validation
	{
		System.out.println("\n\n\t\t ERROR! At data [ "+ word +" ].");
		System.out.println("\n\n\t\t [Max alphabet=7] !\n\n");
		//return 1;
	}
	
	for(int i=0;i<word.length();i++)  
	{
		word1= Character.toLowerCase(word.charAt(i)); //change uppercase to lower case
			
		if(word1=='\u00A0' || word1=='\t')
		{
			System.out.println("\n\n\t\t ERROR! [Space/Tab] exist in data [ "+word+" ].");
			System.out.println("\n\n\t\t Make sure data stored line by line !\n\n");
			//return 1;
		}
	}
	
	for(int i=0;i<word.length();i++)
	{
		for(int j=i+1;j<word.length();j++)
		{
			if(word.charAt(i)==word.charAt(j))
			{
				System.out.println("\n\n\t\t ERROR! [Duplicate] alphabet existed in data [ "+word+" ].");
				System.out.println("\n\n\t\t Try again !\n\n");
			//return 1;
			}
		}
	}
	}
	/*public static void main(String[] args) throws Exception{ 
    	   	
		// a method inside class Application, used to set up program as the JavaFX application.
    	}*/
	
}


